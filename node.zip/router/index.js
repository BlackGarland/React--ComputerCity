var express = require('express');
var router = express.Router();

router.get('/list', function (req, res) {
    console.log(req.session.user)
    res.json([
        'xiaoming',
        'xiaohong',
    ]);
});

router.get("/student/:id", function (req, res) {
    var id = req.params["id"];
    var reg = /^[\d]{6}$/;   //正则验证
    if (reg.test(id)) {
        res.send(id);
    } else {
        res.send("请检查格式");
    }
});

//获取post请求参数，使用body-parser中间件
router.post("/login", function (req, res) {
    console.log(req.body);
    const { name, pwd } = req.body;
    if (name == "zhangsan" && pwd == "123") {
        req.session.user = req.body;
        res.send("登录成功")
    }
    else {
        res.send("登录失败")
    }
})

router.get('/layout', function (req, res) {
    req.session.user = null;
    res.json("退出登录成功");
});

module.exports = router;